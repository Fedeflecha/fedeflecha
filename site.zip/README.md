
# Malov Infra App (PWA, offline-first)

Aplicación lista para usar en tu iPhone (y cualquier navegador moderno). Datos almacenados **solo en tu dispositivo** con IndexedDB, con exportación/importación `.json`.

## Módulos incluidos
- **Proyectos**: alta y seguimiento con estado, fechas y monto.
- **Presupuestos**: ítems con cantidad, unidad, PU y total por proyecto.
- **Stock**: inventario por artículo/código, valor de inventario.
- **Costos/Gastos**: carga por fecha, proyecto, tipo, monto, comprobante.
- **Avances**: registro de hitos con %.
- **Documentación**: guarda archivos (PDF/imagenes) y fechas de vencimiento.
- **Informes**: ejecutivo, costos vs presupuesto, exportar CSV/JSON e impresión PDF.
- **Pliegos**: extrae ítems/fechas/requisitos desde PDF (vía PDF.js online) o texto pegado y los vuelca como presupuesto preliminar.

## Instalación en iPhone
1. Subí esta carpeta a tu hosting (por ejemplo Hostinger) o a cualquier servidor HTTPS.
2. Abrí la URL en **Safari**.
3. Toca el botón **Compartir** → **Agregar a pantalla de inicio**.
4. La app funciona **offline**. Los datos quedan en tu teléfono. Usá **Exportar respaldo** para guardar una copia externa.

## Notas
- La extracción de pliegos depende de que el PDF tenga texto seleccionable. Si no, usa el OCR del iPhone, y pegá el texto.
- Para multi-dispositivo o multi-usuario, hace falta un backend (API) — lo puedo agregar cuando quieras.
- Esto es un MVP funcional pensado para operar YA, y expandirse con tus procesos.


---

## Seguridad y ChatGPT (solo para vos)
- **Bloqueo por PIN local:** activalo en Configuración. Se guarda un hash en tu iPhone. Si lo olvidás, reinstalá la app.
- **Solo offline:** si lo activás en Configuración, la app bloquea cualquier llamada a red (incluida OpenAI).
- **ChatGPT con tu cuenta:** colocá tu **OpenAI API Key** (sk-...) en Configuración. Se guarda **solo** en tu dispositivo y se usa directo contra la API oficial. Requiere conexión.

### Importante
No es técnicamente posible usar ChatGPT completamente **offline**. La parte de la app (proyectos, presupuestos, etc.) sí funciona offline al 100%.
