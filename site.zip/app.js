
const $ = (q) => document.querySelector(q);
const $$ = (q) => Array.from(document.querySelectorAll(q));

// Tab navigation
$$('.tabs button').forEach(b => b.addEventListener('click', () => {
  $$('.tabs button').forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  $$('.tab').forEach(s=>s.classList.remove('active'));
  $('#' + b.dataset.tab).classList.add('active');
}));

// Backup / restore
$('#btn-sync').addEventListener('click', async () => {
  const ok = confirm('¿Exportar respaldo ahora? Aceptar = Exportar, Cancelar = Importar.');
  if (ok) exportarJson(); else $('#btn-importar-json').click();
});

// Empresa
$('#empresa-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  await dbPut('empresa', { id: 'empresa', ...data });
  alert('Datos guardados');
});

// Proyectos
async function cargarProyectosEnSelects() {
  const proyectos = await dbGetAll('proyectos');
  for (const id of ['pres-proyecto','costo-proyecto','avance-proyecto']) {
    const sel = document.getElementById(id);
    sel.innerHTML = '<option value="">(sin proyecto)</option>' + proyectos.map(p=>`<option value="${p.id}">${p.nombre}</option>`).join('');
  }
}
$('#proyecto-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  const id = await dbAdd('proyectos', data);
  e.target.reset();
  renderProyectos();
  cargarProyectosEnSelects();
});
async function renderProyectos() {
  const list = await dbGetAll('proyectos');
  const el = $('#proyecto-list');
  el.innerHTML = '<div class="table"><table><thead><tr><th>Nombre</th><th>Cliente</th><th>Monto</th><th>Inicio</th><th>Fin</th><th>Estado</th><th></th></tr></thead><tbody>' +
    list.map(p=>`<tr><td>${p.nombre||''}</td><td>${p.cliente||''}</td><td>${fmt(p.monto)}</td><td>${p.inicio||''}</td><td>${p.fin||''}</td><td><span class="badge">${p.estado||''}</span></td><td><button data-del="${p.id}">Borrar</button></td></tr>`).join('') +
    '</tbody></table></div>';
  el.querySelectorAll('button[data-del]').forEach(btn=>btn.addEventListener('click', async ()=>{ await dbDelete('proyectos', Number(btn.dataset.del)); renderProyectos(); cargarProyectosEnSelects(); }));
}

// Presupuestos
$('#presupuesto-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.cantidad = parseFloat(data.cantidad||0);
  data.pu = parseFloat(data.pu||0);
  await dbAdd('presupuestos', data);
  e.target.reset();
  renderPresupuestos();
});
async function renderPresupuestos() {
  const rows = await dbGetAll('presupuestos');
  const total = rows.reduce((s,r)=>s + (r.cantidad*r.pu), 0);
  const byProject = {};
  rows.forEach(r => {
    const k = r.proyectoId || '(sin proyecto)';
    byProject[k] = (byProject[k]||0) + (r.cantidad*r.pu);
  });
  $('#presupuesto-table').innerHTML = `
  <div class="card"><div class="kpi">${fmt(total)}</div><div class="kpi-sub">Total presupuestado</div></div>
  <div class="table"><table><thead><tr><th>Proyecto</th><th>Ítem</th><th>Cant.</th><th>Unidad</th><th>PU</th><th>Total</th></tr></thead>
  <tbody>${rows.map(r=>`<tr><td>${r.proyectoId||''}</td><td>${r.item}</td><td>${r.cantidad}</td><td>${r.unidad||''}</td><td>${fmt(r.pu)}</td><td>${fmt(r.cantidad*r.pu)}</td></tr>`).join('')}</tbody></table></div>`;
}

// Stock
$('#stock-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.cantidad = parseFloat(data.cantidad||0);
  data.costo = parseFloat(data.costo||0);
  // Use "codigo" as natural key if provided
  const all = await dbGetAll('stock');
  const found = all.find(x => x.codigo && x.codigo === data.codigo);
  if (found) {
    // update qty and cost
    found.articulo = data.articulo; found.categoria = data.categoria; found.unidad = data.unidad;
    found.cantidad = data.cantidad; found.costo = data.costo;
    await dbPut('stock', found);
  } else {
    await dbAdd('stock', data);
  }
  e.target.reset();
  renderStock();
});
async function renderStock() {
  const rows = await dbGetAll('stock');
  const val = rows.reduce((s,r)=>s + (r.cantidad*(r.costo||0)), 0);
  $('#stock-table').innerHTML = `
  <div class="card"><div class="kpi">${fmt(val)}</div><div class="kpi-sub">Valor de inventario</div></div>
  <div class="table"><table><thead><tr><th>Artículo</th><th>Código</th><th>Categoría</th><th>Unidad</th><th>Cantidad</th><th>Costo u.</th><th>Total</th></tr></thead>
  <tbody>${rows.map(r=>`<tr><td>${r.articulo}</td><td>${r.codigo||''}</td><td>${r.categoria||''}</td><td>${r.unidad||''}</td><td>${r.cantidad}</td><td>${fmt(r.costo||0)}</td><td>${fmt(r.cantidad*(r.costo||0))}</td></tr>`).join('')}</tbody></table></div>`;
}

// Costos / Gastos
$('#costo-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.monto = parseFloat(data.monto||0);
  await dbAdd('costos', data);
  e.target.reset();
  renderCostos();
});
async function renderCostos() {
  const rows = await dbGetAll('costos');
  const total = rows.reduce((s,r)=>s + r.monto, 0);
  $('#costo-table').innerHTML = `
  <div class="card"><div class="kpi">${fmt(total)}</div><div class="kpi-sub">Total gastado</div></div>
  <div class="table"><table><thead><tr><th>Fecha</th><th>Proyecto</th><th>Concepto</th><th>Tipo</th><th>Monto</th><th>Comp.</th></tr></thead>
  <tbody>${rows.map(r=>`<tr><td>${r.fecha}</td><td>${r.proyectoId||''}</td><td>${r.concepto}</td><td>${r.tipo}</td><td>${fmt(r.monto)}</td><td>${r.comprobante||''}</td></tr>`).join('')}</tbody></table></div>`;
}

// Avances
$('#avance-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.porc = parseFloat(data.porc||0);
  await dbAdd('avances', data);
  e.target.reset();
  renderAvances();
});
async function renderAvances() {
  const rows = await dbGetAll('avances');
  $('#avance-table').innerHTML = `
  <div class="table"><table><thead><tr><th>Fecha</th><th>Proyecto</th><th>Descripción</th><th>%</th></tr></thead>
  <tbody>${rows.map(r=>`<tr><td>${r.fecha}</td><td>${r.proyectoId||''}</td><td>${r.desc}</td><td>${r.porc}</td></tr>`).join('')}</tbody></table></div>`;
}

// Documentos (archivos se guardan en IndexedDB como blobs)
$('#doc-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const file = fd.get('archivo');
  let blob = null;
  if (file && file.size) blob = await file.arrayBuffer();
  const doc = {
    titulo: fd.get('titulo'), tipo: fd.get('tipo'), vence: fd.get('vence'),
    archivo: blob ? new Uint8Array(blob) : null,
    nombre: file && file.name ? file.name : null, mime: file && file.type ? file.type : null
  };
  await dbAdd('documentos', doc);
  e.target.reset();
  renderDocs();
});
async function renderDocs() {
  const rows = await dbGetAll('documentos');
  const html = rows.map((d,i)=>{
    const venc = d.vence ? ` (vence ${d.vence})` : '';
    return `<li>${d.titulo} - ${d.tipo||''}${venc} ${d.archivo ? `<button data-open="${i}">Abrir</button>`:''}</li>`;
  }).join('');
  $('#doc-table').innerHTML = `<ul>${html}</ul>`;
  // open buttons
  $('#doc-table').querySelectorAll('button[data-open]').forEach((btn,idx)=>{
    btn.addEventListener('click', async ()=> {
      const list = await dbGetAll('documentos');
      const d = list[idx];
      if (!d || !d.archivo) return;
      const blob = new Blob([d.archivo], { type: d.mime || 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      setTimeout(()=>URL.revokeObjectURL(url), 10000);
    });
  });
}

// Informes
$('#btn-informe-resumen').addEventListener('click', async ()=> {
  const proyectos = await dbGetAll('proyectos');
  const presup = await dbGetAll('presupuestos');
  const costos = await dbGetAll('costos');
  const avances = await dbGetAll('avances');
  const inv = await dbGetAll('stock');
  const sumaPres = presup.reduce((s,r)=>s + r.cantidad*r.pu, 0);
  const sumaCost = costos.reduce((s,r)=>s + r.monto, 0);
  const valorInv = inv.reduce((s,r)=>s + (r.cantidad*(r.costo||0)), 0);
  const promAvance = avances.length ? (avances.reduce((s,r)=>s + r.porc, 0)/avances.length).toFixed(1) : 0;
  $('#informes-output').innerHTML = `
    <div class="cards">
      <div class="card"><div class="kpi">${proyectos.length}</div><div class="kpi-sub">Proyectos</div></div>
      <div class="card"><div class="kpi">${fmt(sumaPres)}</div><div class="kpi-sub">Presupuestado</div></div>
      <div class="card"><div class="kpi">${fmt(sumaCost)}</div><div class="kpi-sub">Gastado</div></div>
      <div class="card"><div class="kpi">${fmt(sumaPres - sumaCost)}</div><div class="kpi-sub">Margen teórico</div></div>
      <div class="card"><div class="kpi">${promAvance}%</div><div class="kpi-sub">Avance promedio</div></div>
      <div class="card"><div class="kpi">${fmt(valorInv)}</div><div class="kpi-sub">Inventario</div></div>
    </div>`;
});
$('#btn-informe-costos').addEventListener('click', async ()=> {
  const presup = await dbGetAll('presupuestos');
  const costos = await dbGetAll('costos');
  const porProyecto = {};
  presup.forEach(p => {
    const k = p.proyectoId || '(sin proyecto)';
    porProyecto[k] = porProyecto[k] || { presup:0, costos:0 };
    porProyecto[k].presup += p.cantidad * p.pu;
  });
  costos.forEach(c => {
    const k = c.proyectoId || '(sin proyecto)';
    porProyecto[k] = porProyecto[k] || { presup:0, costos:0 };
    porProyecto[k].costos += c.monto;
  });
  const rows = Object.entries(porProyecto).map(([k,v])=>({proyecto:k, presup:v.presup, costos:v.costos, diferencia:v.presup - v.costos}));
  $('#informes-output').innerHTML = `
    <div class="table"><table><thead><tr><th>Proyecto</th><th>Presupuesto</th><th>Costos</th><th>Diferencia</th></tr></thead>
    <tbody>${rows.map(r=>`<tr><td>${r.proyecto}</td><td>${fmt(r.presup)}</td><td>${fmt(r.costos)}</td><td>${fmt(r.diferencia)}</td></tr>`).join('')}</tbody></table></div>`;
});
$('#btn-exportar-json').addEventListener('click', exportarJson);
$('#btn-importar-json').addEventListener('click', ()=> $('#importar-json').click());
$('#importar-json').addEventListener('change', importarJson);
$('#btn-exportar-csv').addEventListener('click', exportarCsv);
$('#btn-imprimir').addEventListener('click', ()=> window.print());

async function exportarJson() {
  const data = {
    empresa: (await dbGetAll('empresa')),
    proyectos: await dbGetAll('proyectos'),
    presupuestos: await dbGetAll('presupuestos'),
    stock: await dbGetAll('stock'),
    costos: await dbGetAll('costos'),
    avances: await dbGetAll('avances'),
    documentos: await dbGetAll('documentos').then(arr=>arr.map(d=>({titulo:d.titulo,tipo:d.tipo,vence:d.vence, nombre:d.nombre, mime:d.mime, archivo: d.archivo?Array.from(d.archivo):null})))
  };
  const blob = new Blob([JSON.stringify(data)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement('a'), { href:url, download:`malov_respaldo_${new Date().toISOString().slice(0,10)}.json` });
  a.click(); setTimeout(()=>URL.revokeObjectURL(url), 5000);
}

async function importarJson(e) {
  const file = e.target.files[0]; if (!file) return;
  const text = await file.text();
  const data = JSON.parse(text);
  // naive restore: clear stores by bumping version isn't trivial; we just append
  for (const x of (data.empresa||[])) await dbPut('empresa', x);
  for (const s of ['proyectos','presupuestos','stock','costos','avances','documentos']) {
    for (const x of (data[s]||[])) await dbAdd(s, x);
  }
  alert('Importado. Volvé a abrir las pestañas para ver los datos.');
  renderAll();
}

async function exportarCsv() {
  const rows = await dbGetAll('costos');
  const head = ['fecha','proyectoId','concepto','tipo','monto','comprobante'];
  const csv = [head.join(',')].concat(rows.map(r=>head.map(h=>(r[h]??'')).join(','))).join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement('a'), { href:url, download:`costos_${new Date().toISOString().slice(0,10)}.csv` });
  a.click(); setTimeout(()=>URL.revokeObjectURL(url), 5000);
}

// Dashboard
async function renderDashboard() {
  const presup = await dbGetAll('presupuestos');
  const costos = await dbGetAll('costos');
  const avances = await dbGetAll('avances');
  const totalPres = presup.reduce((s,r)=>s + r.cantidad*r.pu, 0);
  const totalCost = costos.reduce((s,r)=>s + r.monto, 0);
  const promAvance = avances.length ? (avances.reduce((s,r)=>s + r.porc, 0)/avances.length).toFixed(1) : 0;
  $('#dashboard-cards').innerHTML = `
    <div class="card"><div class="kpi">${fmt(totalPres)}</div><div class="kpi-sub">Presupuesto</div></div>
    <div class="card"><div class="kpi">${fmt(totalCost)}</div><div class="kpi-sub">Costos</div></div>
    <div class="card"><div class="kpi">${fmt(totalPres - totalCost)}</div><div class="kpi-sub">Resultado</div></div>
    <div class="card"><div class="kpi">${promAvance}%</div><div class="kpi-sub">Avance promedio</div></div>`;
}

// Pliegos
async function leerPdfComoTexto(file) {
  // Intentar cargar PDF.js desde CDN si hay internet
  try {
    if (!window.pdfjsLib) {
      await new Promise((res, rej) => {
        const s = document.createElement('script');
        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/pdf.min.js';
        s.onload = res; s.onerror = rej; document.head.appendChild(s);
      });
    }
    const arr = new Uint8Array(await file.arrayBuffer());
    const pdf = await pdfjsLib.getDocument({ data: arr }).promise;
    let texto = '';
    for (let i=1;i<=pdf.numPages;i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      texto += content.items.map(it=>it.str).join(' ') + '\n';
    }
    return texto;
  } catch (e) {
    console.warn('No se pudo usar PDF.js, pedimos texto pegado.', e);
    return '';
  }
}

function extraerDelPliego(texto, cfg) {
  const out = { items:[], fechas:[], requisitos:[] };
  const lines = texto.split(/\n|\r/).map(l=>l.trim()).filter(Boolean);
  // Items: buscar lineas tipo "Ítem 1", "Item 1", "Partida", o descripciones con número + unidad
  const itemRegex = /(ítem|item|partida)\s*([0-9]+)[\.:\-\)]?\s*(.*)/i;
  const qtyRegex = /([0-9]+(?:[\.,][0-9]+)?)\s*(m2|m3|m|u|kg|hs|litros|l|m\^2|m\^3|unidades)/i;
  for (const l of lines) {
    let m = l.match(itemRegex);
    if (m) {
      const desc = m[3] || '';
      const qty = desc.match(qtyRegex);
      out.items.push({
        codigo: m[2],
        descripcion: desc,
        cantidad: qty ? parseFloat(qty[1].replace(',','.')) : null,
        unidad: qty ? qty[2] : null
      });
    } else {
      const qty = l.match(qtyRegex);
      if (qty && l.length>8) {
        out.items.push({ codigo:null, descripcion:l, cantidad:parseFloat(qty[1].replace(',','.')), unidad:qty[2] });
      }
    }
  }
  // Fechas: plazos, apertura, entrega
  const fechaRegex = /(apertura|presentaci[oó]n|plazo|entrega|adjudicaci[oó]n)[^0-9]{0,12}([0-3]?[0-9][\/\-\.][0-1]?[0-9][\/\-\.][0-9]{2,4})/i;
  lines.forEach(l => {
    const m = l.match(fechaRegex);
    if (m) out.fechas.push({ tipo:m[1], fecha:m[2] });
  });
  // Requisitos: palabras clave
  const claves = ['garantía de oferta','garantia de oferta','poliza','anticipo','plazo de obra','mantenimiento de oferta','rupe','afip','art','seguro','visado','matricula','antecedentes','certificado','plan de trabajo'];
  lines.forEach(l => {
    const low = l.toLowerCase();
    if (claves.some(c=>low.includes(c))) out.requisitos.push(l);
  });
  return out;
}

$('#pliego-analizar').addEventListener('click', async ()=> {
  const f = document.getElementById('pliego-file').files[0];
  let texto = $('#pliego-texto').value;
  if (f) {
    const pdfTexto = await leerPdfComoTexto(f);
    if (pdfTexto) texto = pdfTexto + '\n' + texto;
  }
  if (!texto.trim()) { alert('Cargá un PDF o pega texto.'); return; }
  const cfg = {
    items: $('#pliego-detectar-items').checked,
    fechas: $('#pliego-detectar-fechas').checked,
    reqs: $('#pliego-detectar-requisitos').checked,
  };
  const res = extraerDelPliego(texto, cfg);
  // Insertar items detectados como presupuesto preliminar
  for (const it of res.items) {
    if (!it.descripcion) continue;
    await dbAdd('presupuestos', { proyectoId:'(pliego)', item: it.descripcion, cantidad: it.cantidad||0, unidad: it.unidad||'', pu: 0, proveedor:'' });
  }
  renderPresupuestos();
  $('#pliego-resultado').innerHTML = `
    <div class="card"><b>Detectados</b>: ${res.items.length} items, ${res.fechas.length} fechas, ${res.requisitos.length} requisitos.</div>
    ${res.fechas.length?'<h3>Fechas clave</h3><ul>'+res.fechas.map(f=>`<li>${f.tipo}: ${f.fecha}</li>`).join('')+'</ul>':''}
    ${res.requisitos.length?'<h3>Requisitos</h3><ul>'+res.requisitos.map(r=>`<li>${r}</li>`).join('')+'</ul>':''}
  `;
  alert('Ítems del pliego volcados a Presupuestos (proyecto "(pliego)"). Revisalos y completá PU.');
});

function fmt(n) { n = parseFloat(n||0); return n.toLocaleString('es-AR', { style:'currency', currency:'ARS', maximumFractionDigits:2 }); }

async function renderAll(){ await Promise.all([renderDashboard(), renderProyectos(), renderPresupuestos(), renderStock(), renderCostos(), renderAvances(), renderDocs(), cargarProyectosEnSelects()]); }
renderAll();



// ===== Seguridad: bloqueo por PIN (local) =====
const LOCK_KEY = 'malov_lock_pin'; // hashed
const AI_CFG_KEY = 'malov_ai_cfg'; // {key, model, offlineOnly}

function sha256(str) {
  const buf = new TextEncoder().encode(str);
  return crypto.subtle.digest('SHA-256', buf).then(b=>Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join(''));
}

function lockOverlay() {
  const div = document.createElement('div');
  div.id = 'lock-overlay';
  div.innerHTML = `
    <div class="box">
      <h2>Malov Infra</h2>
      <p>Ingresá tu código para desbloquear</p>
      <input id="pin-input" type="password" inputmode="numeric" pattern="\d*" maxlength="8" placeholder="••••">
      <button id="pin-ok">Desbloquear</button>
    </div>`;
  document.body.appendChild(div);
  return div;
}

async function requireUnlockIfNeeded() {
  const stored = localStorage.getItem(LOCK_KEY);
  if (!stored) return; // no lock set
  const ov = lockOverlay();
  ov.style.display = 'flex';
  return new Promise(resolve => {
    $('#pin-ok').addEventListener('click', async ()=>{
      const val = $('#pin-input').value.trim();
      const h = await sha256(val);
      if (h === stored) { ov.style.display='none'; resolve(true); }
      else alert('Código incorrecto');
    });
  });
}

// Save lock PIN
$('#lock-form')?.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const pin = new FormData(e.target).get('pin').toString().trim();
  if (!/^\d{4,8}$/.test(pin)) { alert('El código debe ser 4 a 8 dígitos.'); return; }
  const h = await sha256(pin);
  localStorage.setItem(LOCK_KEY, h);
  alert('Código guardado. Se pedirá al abrir la app.');
  e.target.reset();
});

// ===== Configuración de ChatGPT =====
async function getAiCfg() {
  try { return JSON.parse(localStorage.getItem(AI_CFG_KEY)||'{}'); } catch { return {}; }
}
$('#ai-form')?.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const cfg = {
    key: fd.get('key') || '',
    model: fd.get('model') || 'gpt-4o-mini',
    offlineOnly: !!fd.get('offlineOnly')
  };
  localStorage.setItem(AI_CFG_KEY, JSON.stringify(cfg));
  alert('Configuración guardada en este dispositivo.');
  e.target.reset();
});

// ===== Asistente (ChatGPT) =====
async function readFileAsBase64(file) {
  return new Promise((res, rej)=>{
    const fr = new FileReader();
    fr.onload = ()=>{ 
      const b64 = btoa(fr.result.split(',')[1] || '');
      res({name:file.name, type:file.type, data:b64});
    };
    fr.onerror = rej;
    fr.readAsDataURL(file);
  });
}

async function aiAsk(prompt, file) {
  const cfg = await getAiCfg();
  if (cfg.offlineOnly) throw new Error('Modo solo offline activado');
  if (!navigator.onLine) throw new Error('Sin conexión a internet');
  if (!cfg.key) throw new Error('Falta API Key de OpenAI en Configuración');
  const model = cfg.model || 'gpt-4o-mini';

  // Compose system prompt with context of the app
  const system = `Sos un asistente experto en obra pública y privada en Argentina.
  Tenés que ayudar a: presupuestar, extraer ítems de pliegos, armar cronogramas, y detectar requisitos administrativos.
  Cuando te den un pliego, devolvé estructuras claras (CSV o JSON) con: item, descripción, unidad, cantidad.
  Contexto: Empresa Malov Infra. Formato de moneda: ARS.`;

  const messages = [
    { role:'system', content: system },
    { role:'user', content: prompt }
  ];

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${cfg.key}`
  };

  // If it's a PDF or text, include as base64 (for models que aceptan input de archivo a través de content parts)
  let input;
  if (file) {
    input = [ 
      {type:'text', text: prompt},
      {type:'input_text', text: `Archivo adjunto: ${file.name} (${file.type}). Procesalo y devolvé tabla de ítems/fechas/requisitos si corresponde.`}
    ];
    // Note: For simplicity we don't use vision APIs here; recommend paste text for PDFs without text layer.
    messages[1].content = prompt + '\n(Se adjuntó un archivo. Si no podés leer PDFs en este endpoint, pedime el texto pegado.)';
  }

  // OpenAI responses API (Chat Completions compat)
  const body = {
    model,
    messages,
    temperature: 0.2
  };

  const resp = await fetch('https://api.openai.com/v1/chat/completions', {
    method:'POST', headers, body: JSON.stringify(body)
  });
  if (!resp.ok) {
    const t = await resp.text();
    throw new Error('Error API: ' + t);
  }
  const data = await resp.json();
  const text = data.choices?.[0]?.message?.content || '(sin respuesta)';
  return text;
}

$('#ai-send')?.addEventListener('click', async ()=>{
  const ta = $('#ai-input');
  const f = $('#ai-file').files[0];
  const msg = ta.value.trim();
  if (!msg && !f) { alert('Escribí tu consulta o adjuntá un archivo.'); return; }
  const chat = $('#ai-chat');
  chat.innerHTML += `<div><b>Vos:</b> ${msg || '(archivo sin texto)'}${f?' <em>['+f.name+']</em>':''}</div>`;
  try {
    let fileData = null;
    if (f) fileData = await readFileAsBase64(f);
    const ans = await aiAsk(msg, fileData);
    chat.innerHTML += `<div><b>Asistente:</b><pre style="white-space:pre-wrap">${ans.replace(/[&<>]/g, s=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[s]))}</pre></div>`;
  } catch(e) {
    chat.innerHTML += `<div style="color:#b00"><b>Error:</b> ${e.message}</div>`;
  }
});

// On load: enforce lock if needed
requireUnlockIfNeeded();
